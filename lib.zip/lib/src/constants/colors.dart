import 'package:flutter/material.dart';

class ColorsTheme {
  static const Color sunglow = Color(0xFFFFCF56);
  static const Color naplesYellow = Color(0xFFF8E16C);
  // static const Color skyBlue = Color(0xFF9ED0E6);
  static const Color skyBlue = Color(0xFF76D3FE);
  static const Color darkSkyBlue = Color(0xFF26C6F8);
  static const Color orangeWeb = Color(0xFFFAA300);
}