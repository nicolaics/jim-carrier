const String WelcomeScreenImage =
    "assets/images/welcomePage/welcome_screen.png";

const String GoogleImg =
    "assets/images/loginpage/google_icon.png";
