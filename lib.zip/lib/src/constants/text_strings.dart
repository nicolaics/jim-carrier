//Text For Welcome Page
const String AppName = "Jim Carrier";
const String Welcome = "Welcome!";
const String WelcomeMessage = "Connect, Pack, and Send\nIt's That Easy";
//Text For Log In and Sign Up
const String tLogin = "Login";
const String tSignup = "Sign Up";
//Text For Log In Page
const String tLogInMessage = "Hey, \nWelcome \nBack";
const tForgotPw = "Forgot Password?";
